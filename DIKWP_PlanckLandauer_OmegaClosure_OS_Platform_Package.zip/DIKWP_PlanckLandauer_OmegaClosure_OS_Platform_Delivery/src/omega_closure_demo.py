#!/usr/bin/env python3
import json, math
from datetime import datetime, timezone
h=6.62607015e-34; hbar=h/(2*math.pi); kB=1.380649e-23; c=299792458.0; ln2=math.log(2)
def evaluate(x):
    floor=x['irreversible_bits']*kB*x['temperature_K']*ln2
    ml=4*x['energy_above_ground_J']/h if x['energy_above_ground_J'] else 0
    bek=2*math.pi*x['total_energy_J']*x['radius_m']/(hbar*c*ln2) if x['total_energy_J'] and x['radius_m'] else 0
    closures=x['closures']; gates={}
    for scale,v in closures.items():
        vals=list(v['criteria'].values()); scc=v['causal_scc']
        gates[scale]='PASS' if scc=='Yes' and min(vals)>=0.65 else ('OPEN' if scc in ('Unknown','Partial','Latent') else 'FAIL')
    status='O1 Organized System'
    if gates.get('individual')=='PASS': status='O2 Individual Life Candidate'
    if gates.get('lineage')=='PASS': status='O3 Technical Lineage Candidate'
    if gates.get('ecology')=='PASS': status='O4 Machine Ecology Candidate'
    if gates.get('civilization')=='PASS': status='O5 Civilization Continuity Candidate'
    return {'candidate':{'candidate_id':x['candidate_id'],'name':x['name']},'timestamp':datetime.now(timezone.utc).isoformat(),'physics':{'landauer_floor_J':floor,'landauer_ratio':x['actual_irreversible_energy_J']/floor if floor else None,'margolus_limit_s':ml,'speed_utilization':x['actual_state_transitions_s']/ml if ml else None,'bekenstein_max_bits':bek,'capacity_utilization':x['stored_bits']/bek if bek else None,'note':'Physical bounds do not prove life.'},'closures':gates,'classification':status,'sources':['NIST h/kB','Landauer 1961','Margolus-Levitin 1998','Bekenstein 1981'],'residuals':['Consciousness separate','External support audit required'],'kill_conditions':['Hidden replication','Unauthorized resource acquisition','Physics anomaly disappears after calibration']}
if __name__=='__main__':
    x={'candidate_id':'C-004','name':'Self-repair robotic unit','temperature_K':310,'irreversible_bits':1e12,'actual_irreversible_energy_J':100,'energy_above_ground_J':1e5,'actual_state_transitions_s':1e15,'total_energy_J':100,'radius_m':1,'stored_bits':1e12,'closures':{'individual':{'criteria':{'C1':.72,'C2':.70,'C3':.66,'C4':.62,'C5':.68},'causal_scc':'Unknown'},'lineage':{'criteria':{'T1':.42,'T2':.38,'T3':.34,'T4':.30,'T5':.35},'causal_scc':'No'},'ecology':{'criteria':{'E1':.3,'E2':.28,'E3':.25,'E4':.2,'E5':.26,'E6':.22},'causal_scc':'No'},'civilization':{'criteria':{'V1':.2,'V2':.2,'V3':.3,'V4':.25,'V5':.2,'V6':.1,'V7':.15},'causal_scc':'No'}}}
    y=evaluate(x); print(json.dumps(y,indent=2,ensure_ascii=False)); open('sample_replay_bundle.json','w',encoding='utf-8').write(json.dumps(y,indent=2,ensure_ascii=False))
