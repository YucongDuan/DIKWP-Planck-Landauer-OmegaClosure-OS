# Source Ledger

## Primary and official sources
1. NIST CODATA, Planck constant: https://physics.nist.gov/cgi-bin/cuu/Value?h
2. NIST CODATA, reduced Planck constant: https://physics.nist.gov/cgi-bin/cuu/Value?hbar
3. NIST CODATA, Boltzmann constant: https://physics.nist.gov/cgi-bin/cuu/Value?k=
4. Landauer, R. (1961), Irreversibility and Heat Generation in the Computing Process.
5. Bennett, C. H. (2003), Notes on Landauer's principle, reversible computation, and Maxwell's Demon.
6. Margolus, N. & Levitin, L. B. (1998), The maximum speed of dynamical evolution. https://arxiv.org/abs/quant-ph/9710043
7. Bekenstein, J. D. (1981), Universal upper bound on the entropy-to-energy ratio for bounded systems. https://doi.org/10.1103/PhysRevD.23.287
8. Lloyd, S. (2000), Ultimate physical limits to computation. https://arxiv.org/abs/quant-ph/9908043
9. Kofman et al. (2026), Defining Life: A Conversation. DOI: 10.13133/2532-5876/19492. User-supplied PDF.
10. Montevil & Mossio (2015), Biological organisation as closure of constraints.

## Interpretation controls
- Planck's constant sets the quantum scale of action; it is not a universal life threshold.
- Landauer's principle concerns physical implementations of logically irreversible information operations. Semantic compression enters the heat ledger only when mapped to physical erasure or path merging.
- Margolus-Levitin and Bekenstein bounds have explicit applicability assumptions and are treated as theoretical envelopes.
- Life, lineage, ecology, civilization, consciousness and social recognition remain separate axes.
