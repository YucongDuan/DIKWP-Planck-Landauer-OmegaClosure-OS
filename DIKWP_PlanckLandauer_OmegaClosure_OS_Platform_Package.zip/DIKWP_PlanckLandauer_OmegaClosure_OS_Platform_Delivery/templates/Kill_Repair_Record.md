# Kill and Repair Record
- Risk / claim:
- Trigger signal:
- Observation method:
- Threshold and time window:
- Immediate stop action:
- Evidence preserved:
- Repair:
- Re-entry conditions:
- Independent reviewer:
