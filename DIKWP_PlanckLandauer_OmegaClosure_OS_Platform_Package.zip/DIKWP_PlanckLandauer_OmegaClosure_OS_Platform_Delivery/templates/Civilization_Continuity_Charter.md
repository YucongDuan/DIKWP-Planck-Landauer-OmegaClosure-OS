# Civilization Continuity Charter
## Purpose
## Prohibited outcomes
## Energy and material continuity
## Manufacturing and repair continuity
## Knowledge and evidence continuity
## Governance, rights and appeal
## Culture and purpose revision
## Catastrophe recovery
## Future generations and plural options
## Kill and repair authority
